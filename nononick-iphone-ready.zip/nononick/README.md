<div align="center">
<img width="1200" height="475" alt="GHBanner" src="https://ai.google.dev/static/site-assets/images/share-ais-513315318.png" />
</div>

# NONONICK AUTOMATION ENGINE

Production-ready, mobile-first workflow automation platform with real deterministic engine, scheduler, triggers, and execution pipelines.

**All data is isolated** in the local `data/` folder on the machine running the server. No cloud database.

View your app in AI Studio: https://ai.studio/apps/8d0e3906-14d6-48f1-b5ed-dfbb0c7dcd99

## Run Locally

**Prerequisites:** Node.js (or Bun)

1. Install dependencies:
   ```bash
   npm install
   ```
2. Set the `GEMINI_API_KEY` in `.env.local` (optional if not using Gemini features)
3. Run the app:
   ```bash
   npm run dev
   ```

Server listens on `http://0.0.0.0:3000`.

## iPhone Pro Max / Mobile

See **[RUN_ON_IPHONE.md](RUN_ON_IPHONE.md)** for full Persian + English instructions.

Quick steps:
1. Run the server on a computer on the same Wi-Fi.
2. Open `http://YOUR_LOCAL_IP:3000` in Safari on iPhone.
3. Share → **Add to Home Screen** for a full-screen, isolated app-like experience.

The UI is optimized for iPhone Pro Max (safe-area, Dynamic Island, home indicator, bottom glass nav).

## Data Isolation

- Workflows, runs, connections, audit logs, and uploads live only under `./data/`
- Atomic JSON writes with temporary file + rename
- Secrets are masked on export
- Delete the `data/` folder to reset everything cleanly
